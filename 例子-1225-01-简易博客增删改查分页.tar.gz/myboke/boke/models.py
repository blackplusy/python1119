from django.db import models

# Create your models here.
class  Bo(models.Model):
    title=models.CharField(max_length=100)
    content=models.CharField(max_length=280)
    publisher_time=models.DateTimeField(auto_now=True)
    category=models.CharField(max_length=20,default='心情日记')