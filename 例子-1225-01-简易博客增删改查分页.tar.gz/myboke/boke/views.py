from django.shortcuts import render,redirect
from .models import Bo
from django.http import HttpResponse
from django.db.models import *
from django.core.paginator import Paginator
# Create your views here.
def index(request,id):
    #判断id是否有值,没有值为1
    if id=='':
        id=1
    #把数据库的记录拿出来
    bos=Bo.objects.all()
    #把这个数据放到Paginator组件中完成分页，按1页多少条记录来分页
    pages=Paginator(bos,2)
    #取第一页的数据
    pags=pages.page(int(id))
    #获取总页数
    totalpage=pages.num_pages
    #获取页数的列表
    pagelist=pages.page_range
    #为templates建一个传递参数的字典
    context={'bo':pags,'total':totalpage,'lis':pagelist}
    #把这个字典参数放在render的第三个参数，返回到templates中
    return render(request,'index.html',context)
def add(request):
    #先获取前端数据
    title=request.POST.get('title')
    content=request.POST.get('content')
    #调用django的ORM类
    bo=Bo()
    bo.title=title
    bo.content=content
    bo.save()
    return redirect('/index/')
def delete(request,id):
    #取出id对应的当前记录
    print(id)
    bo=Bo.objects.get(pk=int(id))
    #删除数据库指定记录的django方法
    print(bo)
    bo.delete()
    return redirect('/index/')
def edit(request,id):
    #根据id取出对象
    bo=Bo.objects.get(pk=int(id))
    #为templates建一个传递参数的字典
    context={'boke':bo}
    #把这个字典参数放在render的第三个参数，返回到templates
    return render(request,'edit.html',context)
def chuli(request):
    title=request.POST.get('title')
    content=request.POST.get('content')
    id=request.POST.get("id")
    bo=Bo.objects.get(pk=int(id))
    bo.title=title
    bo.content=content
    bo.save()
    return redirect('/index/')
def search(request):
    #接收关键字
    keyboard=request.POST.get('keyboard')
    #从数据库查询是否包含此关键字
    bos=Bo.objects.filter(Q(title__contains=keyboard)|Q(content__contains=keyboard))
    for b in bos:
           b.title=b.title.replace('阴','<span style="color:red">阴</span>')
           b.content=b.content.replace('阴','<span style="color:red">阴</span>')
    context={'bo':bos}
    #含 阴 替换掉  <span style='color:red'>阴</span>
    return render(request,'index.html',context)