from django.shortcuts import render
from hashlib import md5
from .models import User
from django.http import HttpResponse
# Create your views here.
def login(request):
	return render(request,'yaofang/login.html')
def login_handler(request):
	pass
def register(request):
	return render(request,'yaofang/regiester.html')
def register_handler(request):
	username=request.POST.get('username')
	password=request.POST.get('password')
	repassword=request.POST.get('repassword')
	if password==repassword:
		'''
		这段是try except的代码
		try:
			us=User.objects.get(username=username)
			return HttpResponse('已有用户')
		except Exception:
			md=md5()
			md.update(password.encode('utf8'))
			password3=md.hexdigest()
			user=User()
			user.username=username
			user.password=password3
			user.save()
			return HttpResponse('注册成功!');
		'''
		user=User.objects.filter(username=username)
		print(user.values())
		if len(user)==0:
			md=md5()
			md.update(password.encode('utf8'))
			password3=md.hexdigest()
			user=User()
			user.username=username
			user.password=password3
			user.save()
			return HttpResponse('注册成功!');
		else:
			
			return HttpResponse('已有用户')
		
	else:
		return HttpResponse('两次密码不一致');
