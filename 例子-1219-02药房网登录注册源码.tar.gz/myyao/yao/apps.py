from django.apps import AppConfig


class YaoConfig(AppConfig):
    name = 'yao'
