from django.shortcuts import render

# Create your views here.
def register(request):
    context={'title':'生鲜蔬果-注册'}
    return render(request,'register.html',context)
def login(request):
    context = {'title': '生鲜蔬果-登陆'}
    return render(request,'login.html',context)
def info(request):
    context={'s':1}
    return render(request,'user_center_info.html',context)
def order(request):
    context={'s':2}
    return render(request,'user_center_order.html',context)
def site(request):
    context={'s':3}
    return render(request,'user_center_site.html',context)