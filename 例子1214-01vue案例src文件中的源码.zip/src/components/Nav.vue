<template>
  <div class="yf_sort">
    <h3>{{kk}}</h3>
    <div class="yf_sort_div">
      <div class="yf_sort_div_top">
        <ul>
          <li onclick="window.location.href='美食/美食.html'"><img src="../assets/img/wm5.gif"/><p>美食</p></li>
          <li onclick="window.location.href='饮品/饮品.html'"><img src="../assets/img/wm6.gif"/><p>饮品</p></li>
          <li onclick="window.location.href='超市/超市.html'"><img src="../assets/img/wm7.gif"/><p>超市福利</p></li>
          <li><img src="../assets/img/wm8.gif"/><p>早餐当</p></li>
        </ul>
        <div class="yf_sort_div_bottom">
          <ul v-for="ss in slist">
            <li><img src="../assets/img/wm9.gif" v-if="sflag"/><p>{{ss}}</p></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
    export default {
        name: "Nav",
        data(){
          return{
              slist:['蔬菜','新启','外卖','吃午饭'],
              sflag:true,
              kk:'这是个变量'
          }
        }
    }
</script>

<style scoped>
  body,ul,ol,li,dl,dt,dd,table,p,input,h1,h2,h3,h4,h5,h6{margin:0;padding:0;}
  body{font-size:0.025rem;font-family:Arial,"寰蒋闆呴粦";}
  a:link,a:visited{text-decoration:none;outline:none;color:#5E5E5E;}
  a img{border:none;}
  ul,li{list-style:none;}
  a:hover{color:#1C468E;}
  input{vertical-align:middle;}


  body {
    font-family: "寰蒋闆呴粦", "瀹嬩綋", sans-serif;
  }

  li {
    list-style: none;
  }


  .yf_header_top_map_img img{width: 100%;height: 100%;float: left;}

  .yf_header_top_right_img img{width: 100%;height: 100%;}

  .yf_header_search input{color: #9D9FA7;border: none;height: 1.725rem;width: 80%;margin-top: 0.225rem;margin-left: 10%;text-indent: 2.375rem;border-radius: 50px }

  .yf_header_ul ul li a{width: 20%;height: 1.035rem;float: left;list-style: none;color: #fff;line-height: 1.035rem;text-align: center;text-indent: 0.375rem;}
  .yf_sort{width: 100%;height: 11.75rem;float: left;}
  .yf_sort_div{width: 85%;height: 10.325rem;float: left;margin-top: 10%;margin-left: 6%;}
  .yf_sort_div_top{width: 100%;height: 4.863rem;float: left;margin-left: 4%;}
  .yf_sort_div_top ul li{width: 24%;height: 4.863rem;float: left;}
  .yf_sort_div_top ul li img{width: 85%;height: 3.863rem;text-align: center;margin-left: 0.325rem;}
  .yf_sort_div_top ul li p{text-align: center;}
  .yf_sort_div_bottom{width: 100%;height: 4.863rem;float: left;margin-top: 10%}

  .yf_banner img{width: 100%;height: 100%;}

  .yf_Concessions_top_font p:first-of-type{font-size: 1rem;text-align: center;}
  .yf_Concessions_top_font p:last-of-type{font-size: 10%;text-align: center;}

  .yf_Concessions_top_img img{width: 100%;height: 100%;}



  .yf_Recommend h2{color: #9BA0A5;line-height: 2.2rem;text-indent: 1.2rem;}

  .yf_first_img img{width: 100%;height: 100%;}

  .yf_first_right_top_top span{margin-left: 0.675rem;}

  .yf_first_right_top_cen_img img{width: 100%;height: 100%;}
  .yf_first_right_top_cen span:first-of-type{color: #B86238;margin-left: 0.525rem;}
  .yf_first_right_top_cen span:last-of-type{margin-left: 0.525rem;}

  .yf_first_right_top_bot pan,yang,fan{margin-left: 0.025rem;}

  .yf_first_right_but_top sa{margin-left: 1.275m;}

  .footer ul li{
    float: left;
    width: 25%;
    height: 2.9rem;
    text-align: center;
  }
  .footer ul li img{
    width: 1rem;
    height: 1rem;
    float: left;
    margin: 0.6rem 1.95rem 0.195rem;
  }
  .footer ul li p{
    float: left;
    font-size: 0.5rem;
    color: #6b6d6b;
    margin-left: 1.7rem;
  }
</style>
