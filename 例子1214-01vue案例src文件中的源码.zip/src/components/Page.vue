<template>
    <div>
      <Header />
      <Nav />
    </div>
</template>

<script>
    import Nav from './Nav.vue'
    import Header from './Header.vue'
    export default {
        name: "Page",
        components:{
          Nav,
          Header
        }
    }
</script>

<style scoped>

</style>
